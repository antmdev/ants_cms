<?php

class Example {

    public function disPlay() {

        echo "method from example";
    }
}