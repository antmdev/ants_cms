<?php 
class Config {

    const SMTP_HOST = 'smtp.mailtrap.io';
    const SMTP_PORT = 2525;
    const SMTP_USER = 'c3078a8c1416f5';
    const SMTP_PASSWORD = 'def5e6ad20e3ba';

}


?>