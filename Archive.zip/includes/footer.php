<!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Ant Milner's CMS 2019</p>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="/cms/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/cms/js/bootstrap.min.js"></script>

    <!-- scripts -->

    


</body>

</html>
