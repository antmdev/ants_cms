<?php 

// 1) To add functionality where each time you click the author name it displays all posts written by that author.

// 2) To complete the "tags" functionality in posts.php where it prints out the tags, each with a link so you can click on the link and see all posts that use that tag.

//3) Add approve / dissaprove bulk tasks to comments page

//4) Check out the login_modal.php from w3 schools - pops ups looks really cool

?>